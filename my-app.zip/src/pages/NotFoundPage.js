import React from 'react';

function NotFoundPage({logout}){
    return(
        <>
            <h1 className='position-absolute top-50 start-50 translate-middle text-secondary'>404 - PAGE NOT FOUND</h1>
        </> 
    )
}

export default NotFoundPage;