# Capstone Project Dicoding

Caspstone project bertemakan solusi ekonomi kreatif dan pertumbuhan ekonomi

## Find Ideal Worker

Find Ideal Worker adalah aplikasi yang menghubungkan antara penyewa dengan tukang. Aplikasi ini memungkinkan penyewa untuk mencari tukang yang sesuai dari segi biaya ataupun kemampuan.

### `rule`

- Jika ingin mengubah/push github buat branch dulu sesuai kebutuhan dari  branch dev. Contoh branch 'login-page' 
- jika udah selesai ngerjain baru dimerge ke branch dev
- jika di dev branch udah di tes dan bisa berjalan dengan baik, baru di merge ke main/master

### `Insyallah selesai tepat waktu`

